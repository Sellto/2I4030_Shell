Shell to control the raspberry Pi 

Fonctions coded in the shell : 
  
  - Check the GPIO setup 
  - Raspberry CPU - Memory - RAM status
  - Rapsberry CPU temperature diplaying 
